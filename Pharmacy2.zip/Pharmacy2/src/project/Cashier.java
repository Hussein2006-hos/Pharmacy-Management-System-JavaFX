package project;

import java.io.Serializable;
import java.util.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import static project.PharmacyProject.LoginScreen;
import static project.PharmacyProject.allOrders;
import static project.PharmacyProject.allUsers;
import static project.PharmacyProject.stage;

public class Cashier extends User implements Serializable {

    private ArrayList<Order> completedOrders;

    public Cashier(String name, String username, String password) {
        super(name, username, password);
        setRole("cashier");
        this.completedOrders = new ArrayList<>();
    }

    public ArrayList<Order> getCompletedOrders() {
        return completedOrders;
    }

    public void setCompletedOrders(ArrayList<Order> completedOrders) {
        this.completedOrders = completedOrders;
    }

    private void showOrderDetailsPopup(Order order) {
        Stage popup = new Stage();
        popup.setTitle("Order Details");

        VBox root = new VBox(10);
        root.setPadding(new Insets(15));

        Label header = new Label("Order ID: " + order.getId());
        header.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        Label dateLabel = new Label("Date: " + order.getDate());
        Label customerLabel = new Label("Customer: " + (order.getCustomer() != null ? order.getCustomer().getName() : "N/A"));
        Label totalLabel = new Label(String.format("Total: $%.2f", order.getTotalAmount()));
        Label ratingLabel = new Label("Rating: " + order.getRating());

        VBox itemsBox = new VBox(5);
        itemsBox.setPadding(new Insets(10));
        itemsBox.setStyle("-fx-border-color: lightgray; -fx-background-color: #f9f9f9;");

        Label itemsTitle = new Label("Items:");
        itemsTitle.setStyle("-fx-font-weight: bold;");

        for (Map.Entry<Product, Integer> entry : order.getItems().entrySet()) {
            Product p = entry.getKey();
            int qty = entry.getValue();
            Label item = new Label(p.getName() + " x" + qty + " - $" + String.format("%.2f", p.getPrice() * qty));
            itemsBox.getChildren().add(item);
        }

        Button closeBtn = new Button("Close");
        closeBtn.setOnAction(e -> popup.close());

        root.getChildren().addAll(header, dateLabel, customerLabel, totalLabel, ratingLabel, itemsTitle, itemsBox, closeBtn);
        Scene scene = new Scene(root, 400, 400);
        popup.setScene(scene);
        popup.show();
    }

    private Node showOrderHistoryPage() {
        VBox container = new VBox(10);
        container.setPadding(new Insets(15));

        Label title = new Label("Order History");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        container.getChildren().add(title);

        TableView<Order> table = new TableView<>();

        TableColumn<Order, Integer> idCol = new TableColumn<>("Order ID");
        idCol.setCellValueFactory(data -> new javafx.beans.property.SimpleIntegerProperty(data.getValue().getId()).asObject());

        TableColumn<Order, String> dateCol = new TableColumn<>("Date");
        dateCol.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getDate().toString()));

        TableColumn<Order, Double> totalCol = new TableColumn<>("Total Amount");
        totalCol.setCellValueFactory(data -> new javafx.beans.property.SimpleDoubleProperty(data.getValue().getTotalAmount()).asObject());

        TableColumn<Order, String> customerCol = new TableColumn<>("Customer");
        customerCol.setCellValueFactory(data -> {
            Customer customer = data.getValue().getCustomer();
            String name = (customer != null) ? customer.getName() : "N/A";
            return new javafx.beans.property.SimpleStringProperty(name);
        });

        TableColumn<Order, Integer> ratingCol = new TableColumn<>("Rating");
        ratingCol.setCellValueFactory(data -> new javafx.beans.property.SimpleIntegerProperty(data.getValue().getRating()).asObject());

        table.getColumns().addAll(idCol, dateCol, totalCol, customerCol, ratingCol);
        table.getItems().addAll(completedOrders);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        
        table.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2 && table.getSelectionModel().getSelectedItem() != null) {
                Order selectedOrder = table.getSelectionModel().getSelectedItem();
                showOrderDetailsPopup(selectedOrder);
            }
        });

        container.getChildren().add(table);
        return container;
    }

    private void showCartPopup(Customer customer) {
        Stage popupStage = new Stage();
        popupStage.setTitle(customer.getName() + "'s Cart");

        VBox cartContainer = new VBox(10);
        cartContainer.setPadding(new Insets(15));

        Label title = new Label("Customer Cart");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        cartContainer.getChildren().add(title);

        Cart cart = customer.getCart();

        if (cart.getItems().isEmpty()) {
            cartContainer.getChildren().add(new Label("Cart is empty."));
        } else {
            for (Map.Entry<Product, Integer> entry : cart.getItems().entrySet()) {
                Product p = entry.getKey();
                int qty = entry.getValue();

                HBox itemBox = new HBox(10);
                itemBox.setAlignment(Pos.CENTER_LEFT);

                Label nameLabel = new Label(p.getName());
                nameLabel.setPrefWidth(200);

                Label qtyLabel = new Label("Qty: " + qty);
                Label priceLabel = new Label(String.format("Price: $%.2f", p.getPrice()));
                Label totalLabel = new Label(String.format("Total: $%.2f", p.getPrice() * qty));

                itemBox.getChildren().addAll(nameLabel, qtyLabel, priceLabel, totalLabel);
                cartContainer.getChildren().add(itemBox);
            }

            Label totalPriceLabel = new Label(String.format("Total Price: $%.2f", cart.calculateTotal()));
            totalPriceLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 16px;");
            cartContainer.getChildren().add(totalPriceLabel);

            // Checkout Button
            Button checkoutBtn = new Button("Checkout");
            checkoutBtn.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-weight: bold;");
            checkoutBtn.setOnAction(e -> {
                if (!cart.getItems().isEmpty()) {
                    Order order = new Order(customer, this, new HashMap<>(cart.getItems()), cart.calculateTotal());

                    customer.getOrderHistory().add(order);
                    this.getCompletedOrders().add(order);
                    allOrders.add(order);
                    

                    cart.clear();                 
                    showPopupMessage("Order placed successfully!");

                    popupStage.close();
                } else {
                    showPopupMessage("Cart is already empty.");
                }
            });

            cartContainer.getChildren().add(checkoutBtn);
        }

        ScrollPane scrollPane = new ScrollPane(cartContainer);
        scrollPane.setFitToWidth(true);

        Scene scene = new Scene(scrollPane, 450, 450);
        popupStage.setScene(scene);
        popupStage.show();
    }

    public VBox showCustomersPage() {
        // Filter allUsers to only Customer instances
        ObservableList<User> allCustomers = FXCollections.observableArrayList();
        for (User user : allUsers) {
            if (user instanceof Customer) {
                allCustomers.add(user);
            }
        }

        TextField searchField = new TextField();
        searchField.setPromptText("Search Customers...");

        TableView<User> table = new TableView<>();
        TableColumn<User, String> nameCol = new TableColumn<>("Name");
        TableColumn<User, String> usernameCol = new TableColumn<>("Username");
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        usernameCol.setCellValueFactory(new PropertyValueFactory<>("username"));

        table.getColumns().addAll(nameCol, usernameCol);
        table.setItems(allCustomers);

        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal == null || newVal.isEmpty()) {
                table.setItems(allCustomers);
            } else {
                String lower = newVal.toLowerCase();
                ObservableList<User> filteredList = FXCollections.observableArrayList();

                for (User user : allCustomers) {
                    if (user.getName().toLowerCase().contains(lower)
                            || user.getUsername().toLowerCase().contains(lower)) {
                        filteredList.add(user);
                    }
                }
                table.setItems(filteredList);
            }
        });

        // Show popup with cart when row clicked
        table.setRowFactory(tv -> {
            TableRow<User> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (!row.isEmpty() && event.getClickCount() == 1) {
                    User clickedUser = row.getItem();
                    if (clickedUser instanceof Customer) {
                        Customer customer = (Customer) clickedUser;
                        showCartPopup(customer);
                    }
                }
            });
            return row;
        });

        VBox layout = new VBox(10, searchField, table);
        layout.setPadding(new Insets(20));

        return layout;
    }

    @Override
    public Scene homePage() {
        BorderPane root = new BorderPane();

        Label title = new Label("Cashier Menu");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        Button customersBtn = new Button("View Customers");
        customersBtn.setOnAction(e -> root.setCenter(showCustomersPage()));

        Button ordersBtn = new Button("View Orders History");
        ordersBtn.setOnAction(e -> root.setCenter(showOrderHistoryPage()));

        Button logoutBtn = new Button("Logout");
        logoutBtn.setOnAction(e -> stage.setScene(LoginScreen()));

        VBox box = new VBox(15, title, customersBtn, ordersBtn, logoutBtn);
        box.setPadding(new Insets(20));
        box.setAlignment(Pos.CENTER);

        root.setLeft(box);
        root.getStylesheets().add(
            PharmacyProject.class.getResource("style.css").toExternalForm()
        );


        return new Scene(root, 700, 500);
    }

}
