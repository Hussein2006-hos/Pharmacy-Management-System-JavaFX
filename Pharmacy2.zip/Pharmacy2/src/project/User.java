package project;

import java.io.Serializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import static project.PharmacyProject.allUsers;

public abstract class User implements Serializable {

    private static int counter = 1;
    private final int id;
    private String name;
    private String username;
    private String password;
    private String role;

    public User(String name, String username, String password) {
        this.name = name;
        this.username = username;
        this.password = password;
        this.id = counter++;
    }

    public static int getCounter() {
        return counter;
    }

    public static void setCounter(int counter) {
        User.counter = counter;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
    

    public void showPopupMessage(String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null); 
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static User login(String username, String password) {
        for (User u : allUsers) {
            if (u.getUsername().equals(username) && u.getPassword().equals(password)) {
                return u;
            }
        }

        return null;
    }

    public static boolean signup(String name, String username, String password) {
        for (User u : allUsers) {
            if (u.getUsername().equals(username)) {
                return false;
            }
        }

        Customer c = new Customer(name, username, password);
        allUsers.add(c);
        return true;
    }

    @Override
    public String toString() {
        return "User{" + "id=" + id + ", username=" + username + ", password=" + password + ", name=" + name + '}';
    }

    public abstract Scene homePage();

    
}
