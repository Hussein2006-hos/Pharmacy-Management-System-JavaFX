package project;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class Cart implements Serializable {

    private Map<Product, Integer> items;

    public Cart() {
        this.items = new HashMap<>();
    }

    public void addProduct(Product product, int quantity) {
        if (quantity <= 0) return;
    int current = items.getOrDefault(product, 0);
    if (current + quantity > product.getQuantityInStock()) {
        items.put(product, product.getQuantityInStock());
    } else {
        items.put(product, current + quantity);
    }
    }

    public void removeProduct(Product product) {
        if (!items.containsKey(product)) {
            return;
        }

        int currentQty = items.get(product);
        if (currentQty <= 1) {
            items.remove(product);
        } else {
            items.put(product, currentQty - 1);
        }
    }

    public void editProductQuantity(Product product, int newQuantity) {
        if (newQuantity <= 0) {
            items.remove(product);
            return;
        } else {
            if (items.containsKey(product)) {
                items.put(product, newQuantity);
            }
        }
    }
    public double calculateTotal() {
        double total = 0.0;
        for (Map.Entry<Product, Integer> entry : items.entrySet()) {
            Product product = entry.getKey();
            int quantity = entry.getValue();
            total += product.getPrice() * quantity;
        }
        return total;
    }
    public Map<Product, Integer> getItems() {
        return items;
    }

    public void clear() {
        items.clear();
    }

}
