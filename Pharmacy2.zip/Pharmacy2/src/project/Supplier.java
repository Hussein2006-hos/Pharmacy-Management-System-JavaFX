 package project;

import java.io.Serializable;
import java.util.*;

public class Supplier implements Serializable {

    private static int counter = 1;

    private int id;
    private String name;
    private List<Product> products = new ArrayList<>();
    private int pharmacyOrderCount = 0;
    private double pharmacyRevenue = 0;

    public Supplier(String name) {
        this.id = counter++;
        this.name = name;
    }
    public void recordPharmacyOrder(double orderTotal) {
        pharmacyOrderCount++;
        pharmacyRevenue += orderTotal;
    }

    public int getPharmacyOrderCount() {
        return pharmacyOrderCount;
    }

    public double getPharmacyRevenue() {
        return pharmacyRevenue;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public void addProduct(Product p) {
        products.add(p);
    }

    public List<Product> getProducts() {
        return products;
    }

    @Override
    public String toString() {
        return "Supplier #" + id + " - " + name;
    }
}

