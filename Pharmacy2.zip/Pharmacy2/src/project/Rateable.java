package project;

public interface Rateable {

    void rate(int stars);

    int getRating();
}
