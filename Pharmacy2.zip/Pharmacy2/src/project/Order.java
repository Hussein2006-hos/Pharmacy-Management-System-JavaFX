package project;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

public class Order implements Rateable, Serializable {

    private static int counter = 1;
    private final int id;
    private final Customer customer;
    private final Cashier cashier;
    private final Map<Product, Integer> items;
    private final Date date;
    private final double totalAmount;
    private int rating;

    public Order(Customer customer, Cashier cashier, Map<Product, Integer> items, double totalAmount) {
        this.id = counter++;
        this.customer = customer;
        this.cashier = cashier;
        this.items = items;
        this.date = new Date();
        this.totalAmount = totalAmount;
        this.rating = 0;
    }

    private double calculateTotal() {
        return items.entrySet().stream()
                .mapToDouble(entry -> entry.getKey().getPrice() * entry.getValue())
                .sum();
    }

    @Override
    public void rate(int stars) {
        if (stars >= 1 && stars <= 5) {
            this.rating = stars;
        } else {
            System.out.println("⚠️ Rating must be between 1 and 5.");
        }
    }

    @Override
    public int getRating() {
        return rating;
    }

    public int getId() {
        return id;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Cashier getCashier() {
        return cashier;
    }

    public Map<Product, Integer> getItems() {
        return items;
    }

    public Date getDate() {
        return date;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("🧾 Order #" + id + "\n");
        sb.append("Customer: ").append(customer.getName())
                .append(" | Cashier: ").append(cashier.getName())
                .append(" | Date: ").append(date)
                .append(" | Total: ").append(totalAmount)
                .append(" | Rating: ").append(rating == 0 ? "Not rated" : rating + " stars")
                .append("\nItems:\n");

        for (Map.Entry<Product, Integer> entry : items.entrySet()) {
            sb.append("- ").append(entry.getKey().getName())
                    .append(" x ").append(entry.getValue())
                    .append(" = ").append(entry.getKey().getPrice() * entry.getValue())
                    .append("\n");
        }

        return sb.toString();
    }
}
