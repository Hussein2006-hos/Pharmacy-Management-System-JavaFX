package project;

import java.io.Serializable;
import java.util.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import static project.PharmacyProject.LoginScreen;
import static project.PharmacyProject.allProducts;
import static project.PharmacyProject.stage;

public class Customer extends User implements Serializable {

    private ArrayList<Order> orderHistory;
    private Cart cart;

    public Customer(String name, String username, String password) {
        super(name, username, password);
        setRole("customer");
        this.orderHistory = new ArrayList<Order>();
        this.cart = new Cart();
    }

    public ArrayList<Order> getOrderHistory() {
        return orderHistory;
    }

    public void setOrderHistory(ArrayList<Order> orderHistory) {
        this.orderHistory = orderHistory;
    }

    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }

    private void showOrderDetailsPopup(Order order) {
        if (order.getRating() == 0) {
            showRatingPrompt(order);
        } else {
            showOrderDetails(order);
        }
    }

    private void showRatingPrompt(Order order) {
        Stage ratingStage = new Stage();
        ratingStage.setTitle("Enter Rating");

        VBox vbox = new VBox(10);
        vbox.setPadding(new Insets(15));

        Label label = new Label("Please rate this order (1-5):");
        TextField ratingField = new TextField();
        ratingField.setPromptText("Enter a number between 1 and 5");

        Label errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: red;");

        Button submitButton = new Button("Submit");
        submitButton.setOnAction(e -> {
            try {
                int rating = Integer.parseInt(ratingField.getText());
                if (rating >= 1 && rating <= 5) {
                    order.rate(rating); // Assuming there's a setter
                    ratingStage.close();
                    showOrderDetails(order);
                } else {
                    errorLabel.setText("Rating must be between 1 and 5.");
                }
            } catch (NumberFormatException ex) {
                errorLabel.setText("Invalid input. Please enter a number.");
            }
        });

        vbox.getChildren().addAll(label, ratingField, errorLabel, submitButton);
        Scene scene = new Scene(vbox, 300, 150);
        ratingStage.setScene(scene);
        ratingStage.show();
    }

    private void showOrderDetails(Order order) {
        Stage popup = new Stage();
        popup.setTitle("Order Details");

        VBox root = new VBox(10);
        root.setPadding(new Insets(15));

        Label header = new Label("Order ID: " + order.getId());
        header.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        Label dateLabel = new Label("Date: " + order.getDate());
        Label cashierLabel = new Label("Cashier: " + (order.getCashier() != null ? order.getCashier().getName() : "N/A"));
        Label totalLabel = new Label(String.format("Total: $%.2f", order.getTotalAmount()));
        Label ratingLabel = new Label("Rating: " + order.getRating());

        VBox itemsBox = new VBox(5);
        itemsBox.setPadding(new Insets(10));
        itemsBox.setStyle("-fx-border-color: lightgray; -fx-background-color: #f9f9f9;");

        Label itemsTitle = new Label("Items:");
        itemsTitle.setStyle("-fx-font-weight: bold;");

        for (Map.Entry<Product, Integer> entry : order.getItems().entrySet()) {
            Product p = entry.getKey();
            int qty = entry.getValue();
            Label item = new Label(p.getName() + " x" + qty + " - $" + String.format("%.2f", p.getPrice() * qty));
            itemsBox.getChildren().add(item);
        }

        Button closeBtn = new Button("Close");
        closeBtn.setOnAction(e -> popup.close());

        root.getChildren().addAll(header, dateLabel, cashierLabel, totalLabel, ratingLabel, itemsTitle, itemsBox, closeBtn);
        Scene scene = new Scene(root, 400, 400);
        popup.setScene(scene);
        popup.show();
    }

    private Node showOrderHistoryPage() {
        VBox container = new VBox(10);
        container.setPadding(new Insets(15));

        Label title = new Label("Order History");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        container.getChildren().add(title);

        TableView<Order> table = new TableView<>();

        TableColumn<Order, Integer> idCol = new TableColumn<>("Order ID");
        idCol.setCellValueFactory(data -> new javafx.beans.property.SimpleIntegerProperty(data.getValue().getId()).asObject());

        TableColumn<Order, String> dateCol = new TableColumn<>("Date");
        dateCol.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getDate().toString()));

        TableColumn<Order, Double> totalCol = new TableColumn<>("Total Amount");
        totalCol.setCellValueFactory(data -> new javafx.beans.property.SimpleDoubleProperty(data.getValue().getTotalAmount()).asObject());

        TableColumn<Order, String> cashierCol = new TableColumn<>("Cashier");
        cashierCol.setCellValueFactory(data -> {
            Cashier cashier = data.getValue().getCashier();
            String name = (cashier != null) ? cashier.getName() : "N/A";
            return new javafx.beans.property.SimpleStringProperty(name);
        });

        TableColumn<Order, Integer> ratingCol = new TableColumn<>("Rating");
        ratingCol.setCellValueFactory(data -> new javafx.beans.property.SimpleIntegerProperty(data.getValue().getRating()).asObject());

        table.getColumns().addAll(idCol, dateCol, totalCol, cashierCol, ratingCol);
        table.getItems().addAll(orderHistory);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // 🔍 Row click listener for details popup
        table.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2 && table.getSelectionModel().getSelectedItem() != null) {
                Order selectedOrder = table.getSelectionModel().getSelectedItem();
                showOrderDetailsPopup(selectedOrder);
            }
        });

        container.getChildren().add(table);
        return container;
    }

    private ScrollPane showViewProductsPage() {
        VBox productsContainer = new VBox(10);
        productsContainer.setPadding(new Insets(15));

        for (Product p : allProducts) {
            VBox card = new VBox(5);
            card.setPadding(new Insets(10));
            card.setStyle("-fx-border-color: gray; -fx-border-radius: 5; -fx-background-radius: 5; -fx-background-color: #f0f0f0;");

            Label nameLabel = new Label("Name: " + p.getName());
            Label priceLabel = new Label(String.format("Price: $%.2f", p.getPrice()));
            Label stockLabel = new Label("In Stock: " + p.getQuantityInStock());
            Label supplierLabel = new Label("Supplier: " + p.getSupplierName());
            Label soldLabel = new Label("Total Sold: " + p.getTotalSold());

            Button addToCartBtn = new Button("Add to Cart");

            addToCartBtn.setDisable(p.getQuantityInStock() <= 0);

            addToCartBtn.setOnAction(e -> {
                if (p.getQuantityInStock() > 0) {
                    cart.addProduct(p, 1); 
                    showPopupMessage(p.getName() + " added to cart!");
                } else {
                    showPopupMessage(p.getName() + " is out of stock!");
                }
            });

            HBox cardContent = new HBox(10);
            VBox infoBox = new VBox(3, nameLabel, priceLabel, stockLabel, supplierLabel, soldLabel);
            infoBox.setPrefWidth(400);

            cardContent.getChildren().addAll(infoBox, addToCartBtn);
            card.getChildren().add(cardContent);

            productsContainer.getChildren().add(card);
        }

        ScrollPane scrollPane = new ScrollPane(productsContainer);
        scrollPane.setFitToWidth(true);
        scrollPane.setPadding(new Insets(10));

        return scrollPane;
    }

    private Node showCartPage() {
        VBox cartContainer = new VBox(10);
        cartContainer.setPadding(new Insets(15));

        Label title = new Label("Your Cart");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        cartContainer.getChildren().add(title);

        if (cart.getItems().isEmpty()) {
            cartContainer.getChildren().add(new Label("Your cart is empty."));
            return cartContainer;
        }

        for (Map.Entry<Product, Integer> entry : cart.getItems().entrySet()) {
            Product p = entry.getKey();
            int qty = entry.getValue();

            HBox itemBox = new HBox(10);
            itemBox.setAlignment(Pos.CENTER_LEFT);

            Label nameLabel = new Label(p.getName());
            nameLabel.setPrefWidth(200);

            Label qtyLabel = new Label("Qty: " + qty);
            Label priceLabel = new Label(String.format("Price: $%.2f", p.getPrice()));
            Label totalLabel = new Label(String.format("Total: $%.2f", p.getPrice() * qty));

            Button removeBtn = new Button("Remove");
            removeBtn.setOnAction(e -> {
                cart.removeProduct(p);
                showPopupMessage(p.getName() + " remove successfully");
            });

            itemBox.getChildren().addAll(nameLabel, qtyLabel, priceLabel, totalLabel, removeBtn);
            cartContainer.getChildren().add(itemBox);
        }

        Label totalPriceLabel = new Label(String.format("Total Price: $%.2f", cart.calculateTotal()));
        totalPriceLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 16px;");
        cartContainer.getChildren().add(totalPriceLabel);

        return new ScrollPane(cartContainer);
    }

    @Override
    public Scene homePage() {
        BorderPane root = new BorderPane();

        Label title = new Label("Customer Menu");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        Button viewProductsBtn = new Button("View Products");
        viewProductsBtn.setOnAction(e -> root.setCenter(showViewProductsPage()));

        Button viewCartBtn = new Button("View Cart");
        viewCartBtn.setOnAction(e -> root.setCenter(showCartPage()));

        Button viewHistoryBtn = new Button("View Order History");
        viewHistoryBtn.setOnAction(e -> root.setCenter(showOrderHistoryPage()));

        Button logoutBtn = new Button("Logout");
        logoutBtn.setOnAction(e -> stage.setScene(LoginScreen()));

        VBox box = new VBox(15, title, viewProductsBtn, viewCartBtn, viewHistoryBtn, logoutBtn);
        box.setPadding(new Insets(20));
        box.setAlignment(Pos.CENTER);

        root.setLeft(box);
        root.getStylesheets().add(
            PharmacyProject.class.getResource("style.css").toExternalForm()
        );

        root.setCenter(showViewProductsPage());

        return new Scene(root, 800, 500);
    }
}
