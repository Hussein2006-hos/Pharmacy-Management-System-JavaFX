package project;

import java.io.*;

public class Product implements Serializable {

    private static int counter = 1;
    private final int id;
    private String name;
    private double price;
    private int quantityInStock;
    private String supplierName;
    private int totalSold;
    private Supplier supplier;
    
    public Product(String name, double price, int quantityInStock, Supplier supplierName) {
        this.id = counter++;
        this.name = name;
        this.price = price;
        this.quantityInStock = quantityInStock;
        this.totalSold = 0;
        this.supplier=supplierName;
    }

    public void updateDetails(String name, double price, int quantityInStock,int quantity) {
        this.name = name;
        this.price = price;
        this.quantityInStock = quantityInStock;
        quantityInStock -= quantity;
        totalSold += quantity;
    }

    public void sell(int quantity) {
        quantityInStock -= quantity;
        totalSold += quantity;
    }

    public double getRevenue() {
        return totalSold * price;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setQuantityInStock(int quantityInStock) {
        this.quantityInStock = quantityInStock;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }
    
    public double getPrice() {
        return price;
    }

    public int getQuantityInStock() {
        return quantityInStock;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public int getTotalSold() {
        return totalSold;
    }
     public Supplier getSupplier() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    public static void saveToFile(Product product, String path) {
        try {
            File dir = new File(path).getParentFile();
            if (dir != null && !dir.exists()) dir.mkdirs();

            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(path));
            oos.writeObject(product);
            oos.close();
            System.out.println("✅ Product saved to " + path);
        } catch (IOException e) {
            System.out.println("❌ Failed to save product: " + e.getMessage());
        }
    }

    @Override
    public String toString() {
        return "Product{" +
                "ID=" + id +
                ", Name='" + name + '\'' +
                ", Price=" + price +
                ", In Stock=" + quantityInStock +
                ", Supplier='" + supplierName + '\'' +
                ", Total Sold=" + totalSold +
                '}';
    }

}
