package project;
import java.io.*;
import java.util.*;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class PharmacyProject extends Application {

    public static ArrayList<User> allUsers = new ArrayList<>();
    public static ArrayList<Product> allProducts = new ArrayList<>();
    public static ArrayList<Order> allOrders = new ArrayList<>();
    public static ArrayList<Supplier> allSuppliers = new ArrayList<>();
    public static Stage stage;

    public static void main(String[] args) {
        loadAll();
        System.out.println(allUsers);
        if (allUsers.isEmpty()) {
            User defaultAdmin = new Admin("admin", "admin", "admin");
            allUsers.add(defaultAdmin);
        }
        launch(args);
        saveAll();
    }

    public static void writeToFile(Object object, String path) {
        try {
            ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(new File(path)));
            o.writeObject(object);
            o.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    @Override
    public void start(Stage stage) throws Exception {
        this.stage = stage;
        stage.setTitle("Pharamcy System");
        stage.setScene(LoginScreen());
        stage.show();
    }

    public static Scene LoginScreen() {

        Label userLabel = new Label("Username:");
        TextField usernameField = new TextField();
        Label passLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();

        Button loginButton = new Button("Login");
        Button signupButton = new Button("Sign Up");
        Button exitButton = new Button("Exit");

        Label messageLabel = new Label();
        messageLabel.setStyle("-fx-text-fill: red;");

        signupButton.setOnAction(e -> stage.setScene(SignupScreen()));

        loginButton.setOnAction((e) -> {
            User u = User.login(usernameField.getText(), passwordField.getText());
            if (u == null) {
                messageLabel.setText("Invalid username or password");
            } else {
                stage.setScene(u.homePage());
            }
        });

        exitButton.setOnAction(e -> stage.close());

        VBox vbox = new VBox(10, userLabel, usernameField, passLabel, passwordField,
                loginButton, signupButton, exitButton, messageLabel);
        vbox.setStyle("-fx-padding: 20;");

        Scene scene = new Scene(vbox, 500, 500);

        // ⭐ ADD CSS HERE ⭐
        scene.getStylesheets().add(
        PharmacyProject.class.getResource("style.css").toExternalForm()
        );

        return scene;
    }

    public static Scene SignupScreen() {

        Label nameLabel = new Label("Name:");
        TextField nameField = new TextField();

        Label userLabel = new Label("Username:");
        TextField usernameField = new TextField();

        Label passLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();

        Button signupButton = new Button("Sign Up");
        Button backButton = new Button("Back to Login");

        Label messageLabel = new Label();
        messageLabel.setStyle("-fx-text-fill: red;");

        backButton.setOnAction(e -> stage.setScene(LoginScreen()));

        signupButton.setOnAction((e) -> {
            String name = nameField.getText().trim();
            String username = usernameField.getText().trim();
            String password = passwordField.getText().trim();

            if (name.isEmpty() || username.isEmpty() || password.isEmpty()) {
                messageLabel.setText("All fields are required.");
                return;
            }

            boolean isCreated = User.signup(name, username, password);
            if (isCreated) {
                messageLabel.setStyle("-fx-text-fill: green;");
                messageLabel.setText("Account created!");
            } else {
                messageLabel.setStyle("-fx-text-fill: red;");
                messageLabel.setText("Username already exists.");
            }
        });

        VBox vbox = new VBox(10, nameLabel, nameField,
                userLabel, usernameField, passLabel, passwordField,
                signupButton, backButton, messageLabel);

        vbox.setStyle("-fx-padding: 20;");

        Scene scene = new Scene(vbox, 500, 500);

        // ⭐ ADD CSS HERE ⭐
       scene.getStylesheets().add(
       PharmacyProject.class.getResource("style.css").toExternalForm()
        );

        return scene;
    }

    public static void saveAll() {
        writeToFile(allUsers, "users.dat");
        writeToFile(allProducts, "products.dat");
        writeToFile(allOrders, "orders.dat");
        writeToFile(allSuppliers, "Suppliers.dat");
    }

    public static void loadAll() {
        Object t = readFromFile("users.dat");
        allUsers = t == null ? new ArrayList<User>() : (ArrayList<User>) t;

        Object t2 = readFromFile("products.dat");
        allProducts = t2 == null ? new ArrayList<Product>() : (ArrayList<Product>) t2;

        Object t3 = readFromFile("orders.dat");
        allOrders = t3 == null ? new ArrayList<Order>() : (ArrayList<Order>) t3;

        Object t4 = readFromFile("Suppliers.dat");
        allSuppliers = t4 == null ? new ArrayList<Supplier>() : (ArrayList<Supplier>) t4;
    }

    public static Object readFromFile(String path) {
        Object object = null;
        try {
            ObjectInputStream i = new ObjectInputStream(new FileInputStream(new File(path)));
            object = i.readObject();
            i.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
        return object;
    }
}