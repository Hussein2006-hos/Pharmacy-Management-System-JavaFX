package project;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import static project.PharmacyProject.LoginScreen;
import static project.PharmacyProject.allProducts;
import static project.PharmacyProject.allUsers;
import static project.PharmacyProject.allSuppliers;
import static project.PharmacyProject.stage;

public class Admin extends User implements Serializable {

    public Admin(String username, String password, String name) {
        super(username, password, name);
    }

    public static boolean addProduct(String name, double price, int quantity, Supplier supplier) {
        for (Product p : allProducts) {
            if (p.getName().equalsIgnoreCase(name)) {
                return false;
            }
        }
        Product product = new Product(name, price, quantity, supplier);
        allProducts.add(product);
        PharmacyProject.saveAll();
        return true;
    }

    public void showAddProductWindow() {
        Stage popup = new Stage();
        popup.setTitle("Add Product");

        TextField nameField = new TextField();
        TextField priceField = new TextField();
        TextField quantityField = new TextField();
        ComboBox<Supplier> supplierBox = new ComboBox<>();
        supplierBox.getItems().addAll(allSuppliers);

        Button saveBtn = new Button("Save");
        saveBtn.setOnAction(e -> {
            String name = nameField.getText().trim();
            String priceStr = priceField.getText().trim();
            String quantityStr = quantityField.getText().trim();
            Supplier supplier = supplierBox.getValue();
            
            if (supplier == null) {
             showPopupMessage("Select a supplier");
             return;
            }

            if (name.isEmpty() || priceStr.isEmpty() || quantityStr.isEmpty()) {
                showPopupMessage("All fields are required.");
                return;
            }

            double price;
            int quantity;

            try {
                price = Double.parseDouble(priceStr);
                quantity = Integer.parseInt(quantityStr);
            } catch (NumberFormatException ex) {
                showPopupMessage("Price must be a number and Quantity must be an integer.");
                return;
            }

            boolean created = addProduct(name, price, quantity, supplier);
            if (created) {
                showPopupMessage("Product added!");
                popup.close();
            } else {
                showPopupMessage("Product already exists.");
            }
        });

        VBox layout = new VBox(10,
                new Label("Name:"), nameField,
                new Label("Price:"), priceField,
                new Label("Quantity:"), quantityField,
                new Label("Supplier:"),supplierBox,
                saveBtn);
        layout.setPadding(new Insets(10));

        popup.setScene(new Scene(layout, 300, 350));
        popup.showAndWait();
    }

    public void showRemoveProductWindow() {
        Stage removeProductStage = new Stage();
        removeProductStage.setTitle("Remove Product");

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(15));
        layout.setAlignment(Pos.CENTER);

        Label label = new Label("Enter Product Name to Remove:");
        TextField productField = new TextField();
        productField.setPromptText("Product Name");

        Label msg = new Label();

        Button removeBtn = new Button("Remove Product");
        removeBtn.setOnAction(e -> {
            String productName = productField.getText().trim();

            if (productName.isEmpty()) {
                msg.setText("Please enter a product name.");
                return;
            }

            boolean found = false;
            for (Product p : allProducts) {
                if (p.getName().equalsIgnoreCase(productName)) {
                    allProducts.remove(p);
                    PharmacyProject.saveAll();
                    msg.setText("Product removed successfully!");
                    found = true;
                    break;
                }
            }

            if (!found) {
                msg.setText("Product not found!");
            }
        });

        Button closeBtn = new Button("Close");
        closeBtn.setOnAction(e -> removeProductStage.close());

        layout.getChildren().addAll(label, productField, removeBtn, msg, closeBtn);

        Scene scene = new Scene(layout, 300, 250);
        removeProductStage.setScene(scene);
        removeProductStage.show();
    }

    public void showEditProductWindow() {
        Stage editProductStage = new Stage();
        editProductStage.setTitle("Edit Product");

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(15));
        layout.setAlignment(Pos.CENTER);

        Label label = new Label("Enter Product Name to Edit:");
        TextField productField = new TextField();
        productField.setPromptText("Product Name");

        Label msg = new Label();

        Button searchBtn = new Button("Search");
        VBox editForm = new VBox(10);
        editForm.setAlignment(Pos.CENTER);

        final Product[] foundProductRef = new Product[1];

        searchBtn.setOnAction(e -> {
            String productName = productField.getText().trim();

            if (productName.isEmpty()) {
                msg.setText("Please enter a product name.");
                editForm.getChildren().clear();
                return;
            }

            foundProductRef[0] = null;
            for (Product p : allProducts) {
                if (p.getName().equalsIgnoreCase(productName)) {
                    foundProductRef[0] = p;
                    break;
                }
            }

            if (foundProductRef[0] == null) {
                showPopupMessage("Product not found!");
                editForm.getChildren().clear();
                return;
            }

            msg.setText("Product found! Edit below:");

            TextField newNameField = new TextField(foundProductRef[0].getName());
            TextField newPriceField = new TextField(String.valueOf(foundProductRef[0].getPrice()));
            TextField newQuantityField = new TextField(String.valueOf(foundProductRef[0].getQuantityInStock()));
            TextField newSupplierField = new TextField(foundProductRef[0].getSupplierName());

            Button saveBtn = new Button("Save Changes");
            saveBtn.setOnAction(ev -> {
                Product target = foundProductRef[0];
                target.setName(newNameField.getText().trim());
                try {
                    target.setPrice(Double.parseDouble(newPriceField.getText().trim()));
                    target.setQuantityInStock(Integer.parseInt(newQuantityField.getText().trim()));
                    target.setSupplierName(newSupplierField.getText().trim());
                    PharmacyProject.saveAll();
                    showPopupMessage("Product updated successfully!");
                } catch (NumberFormatException ex) {
                    msg.setText("Invalid number format for price or quantity!");
                }
            });

            editForm.getChildren().setAll(
                    new Label("New Name:"), newNameField,
                    new Label("New Price:"), newPriceField,
                    new Label("New Quantity:"), newQuantityField,
                    new Label("New Supplier:"), newSupplierField,
                    saveBtn
            );
        });

        Button closeBtn = new Button("Close");
        closeBtn.setOnAction(e -> editProductStage.close());

        layout.getChildren().addAll(label, productField, searchBtn, msg, editForm, closeBtn);

        Scene scene = new Scene(layout, 360, 560);
        editProductStage.setScene(scene);
        editProductStage.show();
    }

    public VBox showProductsPage() {
        ObservableList<Product> observableProductList = FXCollections.observableArrayList(allProducts);

        TextField searchField = new TextField();
        searchField.setPromptText("Search Products...");

        TableView<Product> table = new TableView<>();

        TableColumn<Product, Integer> idCol = new TableColumn<>("ID");
        TableColumn<Product, String> nameCol = new TableColumn<>("Name");
        TableColumn<Product, Double> priceCol = new TableColumn<>("Price");
        TableColumn<Product, Integer> quantityCol = new TableColumn<>("Quantity");
        TableColumn<Product, String> supplierCol = new TableColumn<>("Supplier");
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        quantityCol.setCellValueFactory(new PropertyValueFactory<>("quantityInStock"));
        supplierCol.setCellValueFactory(cellData ->new ReadOnlyStringWrapper(
        cellData.getValue().getSupplier() != null
            ? cellData.getValue().getSupplier().getName()
            : "N/A"
         )
         );
        table.getColumns().addAll(idCol, nameCol, priceCol, quantityCol, supplierCol);

        table.setItems(observableProductList);

        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal == null || newVal.isEmpty()) {
                table.setItems(observableProductList);
            } else {
                String lower = newVal.toLowerCase();
                ObservableList<Product> filteredList = FXCollections.observableArrayList();

                for (Product product : observableProductList) {
                    if (product.getName().toLowerCase().contains(lower)
                            || product.getSupplierName().toLowerCase().contains(lower)) {
                        filteredList.add(product);
                    }
                }
                table.setItems(filteredList);
            }
        });

        Button addProductBtn = new Button("Add Product");
        Button removeProductBtn = new Button("Remove Product");
        Button editProductBtn = new Button("Edit Product");
        addProductBtn.setOnAction(e -> showAddProductWindow());
        removeProductBtn.setOnAction(e -> showRemoveProductWindow());
        editProductBtn.setOnAction(e -> showEditProductWindow());

        VBox layout = new VBox(10, searchField, table,new HBox(10,addProductBtn, removeProductBtn, editProductBtn));
        layout.setPadding(new Insets(20));
        return layout;
    }

    public static boolean addUser(String name, String username, String password, String type) {
        for (User u : allUsers) {
            if (u.getUsername().equals(username)) {
                return false;
            }
        }
        User u;

        if (type.equals("admin")) {
            u = new Admin(name, username, password);
        } else if (type.equals("cashier")) {
            u = new Cashier(name, username, password);
        } else {
            u = new Customer(name, username, password);
        }
        allUsers.add(u);
        PharmacyProject.saveAll();
        return true;
    }

    public void showAddUserWindow() {
        Stage popup = new Stage();
        popup.setTitle("Add User");

        TextField nameField = new TextField();
        TextField usernameField = new TextField();
        PasswordField passwordField = new PasswordField();
        ComboBox<String> typeBox = new ComboBox<>();
        typeBox.getItems().addAll("admin", "customer", "cashier");
        typeBox.setValue("customer");

        Button saveBtn = new Button("Save");
        saveBtn.setOnAction(e -> {
            String name = nameField.getText().trim();
            String username = usernameField.getText().trim();
            String password = passwordField.getText().trim();

            if (name.isEmpty() || username.isEmpty() || password.isEmpty()) {
                showPopupMessage("All fields are required.");
                return;
            }
            boolean isCreated = addUser(name, username, password, typeBox.getValue());

            if (isCreated) {
                showPopupMessage("Account created!");
                popup.close();
            } else {
                showPopupMessage("Username already exists.");
            }

        });

        VBox layout = new VBox(10, new Label("Name:"), nameField,
                new Label("Username:"), usernameField,
                new Label("Password:"), passwordField,
                new Label("Type:"), typeBox, saveBtn);
        layout.setPadding(new Insets(10));

        popup.setScene(new Scene(layout, 300, 300));
        popup.showAndWait();
    }

    public void showEditUserWindow() {
        Stage editUserStage = new Stage();
        editUserStage.setTitle("Edit User");

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(15));
        layout.setAlignment(Pos.CENTER);

        Label label = new Label("Enter Username to Edit:");
        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        Label msg = new Label();

        Button searchBtn = new Button("Search");
        VBox editForm = new VBox(10);
        editForm.setAlignment(Pos.CENTER);

        final User[] foundUserRef = new User[1];

        searchBtn.setOnAction(e -> {
            String username = usernameField.getText().trim();

            if (username.isEmpty()) {
                msg.setText("Please enter a username.");
                editForm.getChildren().clear();
                return;
            }

            foundUserRef[0] = null;
            for (User u : allUsers) {
                if (u.getUsername().equalsIgnoreCase(username)) {
                    foundUserRef[0] = u;
                    break;
                }
            }

            if (foundUserRef[0] == null) {
                msg.setText("User not found!");
                editForm.getChildren().clear();
                return;
            }

            msg.setText("User found! Edit below:");

            TextField newNameField = new TextField(foundUserRef[0].getUsername());
            TextField newPassField = new TextField(foundUserRef[0].getPassword());
            ComboBox<String> newRoleField = new ComboBox<>();
            newRoleField.getItems().addAll("Admin", "Customer", "Cashier");
            newRoleField.setValue("Customer");

            Button saveBtn = new Button("Save Changes");
            saveBtn.setOnAction(ev -> {
                User target = foundUserRef[0];
                target.setUsername(newNameField.getText());
                target.setPassword(newPassField.getText());
                target.setRole(newRoleField.getValue());
                PharmacyProject.saveAll();
                showPopupMessage("User updated successfully!");
            });

            editForm.getChildren().setAll(
                    new Label("New Username:"), newNameField,
                    new Label("New Password:"), newPassField,
                    new Label("New Role:"), newRoleField,
                    saveBtn
            );
        });

        Button closeBtn = new Button("Close");
        closeBtn.setOnAction(e -> editUserStage.close());

        layout.getChildren().addAll(label, usernameField, searchBtn, msg, editForm, closeBtn);

        Scene scene = new Scene(layout, 320, 460);
        editUserStage.setScene(scene);
        editUserStage.show();
    }

    public void showRemoveUserWindow() {
        Stage removeUserStage = new Stage();
        removeUserStage.setTitle("Remove User");

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(15));
        layout.setAlignment(Pos.CENTER);

        Label label = new Label("Enter Username to Remove:");
        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        Label msg = new Label();

        Button removeBtn = new Button("Remove User");
        removeBtn.setOnAction(e -> {
            String username = usernameField.getText().trim();

            if (username.isEmpty()) {
                msg.setText("Please enter a username.");
                return;
            }

            boolean found = false;
            for (User u : allUsers) {
                if (u.getUsername().equalsIgnoreCase(username)) {
                    allUsers.remove(u);
                    PharmacyProject.saveAll();
                    msg.setText("User removed successfully!");
                    found = true;
                    break;
                }
            }

            if (!found) {
                msg.setText("User not found!");
            }
        });

        Button closeBtn = new Button("Close");
        closeBtn.setOnAction(e -> removeUserStage.close());

        layout.getChildren().addAll(label, usernameField, removeBtn, msg, closeBtn);

        Scene scene = new Scene(layout, 300, 250);
        removeUserStage.setScene(scene);
        removeUserStage.show();
    }

    public VBox showUsersPage() {
        ObservableList<User> observableUserList = FXCollections.observableArrayList(allUsers);

        TextField searchField = new TextField();
        searchField.setPromptText("Search Users...");

        TableView<User> table = new TableView<>();
        TableColumn<User, String> nameCol = new TableColumn<>("Name");
        TableColumn<User, String> usernameCol = new TableColumn<>("Username");
        TableColumn<User, String> typeCol = new TableColumn<>("Type");
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        usernameCol.setCellValueFactory(new PropertyValueFactory<>("username"));

        typeCol.setCellValueFactory(cellData -> {
            User user = cellData.getValue();
            String className = user.getClass().getSimpleName();
            return new ReadOnlyStringWrapper(className);
        });

        table.getColumns().addAll(nameCol, usernameCol, typeCol);

        table.setItems(observableUserList);

        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal == null || newVal.isEmpty()) {
                table.setItems(observableUserList);
            } else {
                String lower = newVal.toLowerCase();
                ObservableList<User> filteredList = FXCollections.observableArrayList();

                for (User user : observableUserList) {
                    if (user.getName().toLowerCase().contains(lower)
                            || user.getUsername().toLowerCase().contains(lower)
                            || user.getClass().getSimpleName().toLowerCase().contains(lower)) {
                        filteredList.add(user);
                    }
                }
                table.setItems(filteredList);
            }
        });

        Button addUserBtn = new Button("Add User");
        Button removeUserBtn = new Button("Remove User");
        Button editUserBtn = new Button("Edit User");
        addUserBtn.setOnAction(e -> showAddUserWindow());
        removeUserBtn.setOnAction(e -> showRemoveUserWindow());
        editUserBtn.setOnAction(e -> showEditUserWindow());
        
        VBox layout = new VBox(10,searchField, table, new HBox(10, addUserBtn, removeUserBtn, editUserBtn));
        layout.setPadding(new Insets(20));
        return layout;
    }
    
    private List<Order> getOrdersByDateRange(LocalDate from, LocalDate to) {

    List<Order> result = new ArrayList<>();

    for (Order o : PharmacyProject.allOrders) {

        LocalDate orderDate = o.getDate().toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDate();

        boolean afterFrom = (from == null) || !orderDate.isBefore(from);
        boolean beforeTo = (to == null) || !orderDate.isAfter(to);

        if (afterFrom && beforeTo) {
            result.add(o);
        }
    }

    return result;
}

   public VBox showReportsPage() {

    VBox layout = new VBox(15);
    layout.setPadding(new Insets(20));
    layout.setAlignment(Pos.TOP_CENTER);

    Label title = new Label("Reports");
    title.setStyle("-fx-font-size: 22px; -fx-font-weight: bold;");

    DatePicker fromDate = new DatePicker();
    fromDate.setPromptText("From");

    DatePicker toDate = new DatePicker();
    toDate.setPromptText("To");

    HBox dateBox = new HBox(10, new Label("Date Range:"), fromDate, toDate);
    dateBox.setAlignment(Pos.CENTER);

    Button supplierBtn = new Button("Supplier Reports");
    Button productBtn = new Button("Product Reports");
    Button customerBtn = new Button("Customer Reports");
    Button cashierBtn = new Button("Cashier Reports");

    HBox buttons = new HBox(10, supplierBtn, productBtn, customerBtn, cashierBtn);
    buttons.setAlignment(Pos.CENTER);

    VBox reportBox = new VBox(10);
    reportBox.setPadding(new Insets(15));
    reportBox.setStyle("-fx-border-color: #ccc; -fx-background-color: #f9f9f9;");

    supplierBtn.setOnAction(e -> {
        reportBox.getChildren().clear();
    
        if (allSuppliers.isEmpty()) {
            reportBox.getChildren().add(new Label("No suppliers available."));
            return;
        }

        Supplier maxOrders = allSuppliers.get(0);
        Supplier maxRevenue = allSuppliers.get(0);

        for (Supplier s : allSuppliers) {
            if (s.getPharmacyOrderCount() > maxOrders.getPharmacyOrderCount())
                maxOrders = s;
            if (s.getPharmacyRevenue() > maxRevenue.getPharmacyRevenue())
                maxRevenue = s;
        }

        Label s1 = new Label("Supplier With Most Orders:");
        Label s1d = new Label("- " + maxOrders.getName() + " (" + maxOrders.getPharmacyOrderCount() + " orders)");

        Label s2 = new Label("Supplier With Highest Revenue:");
        Label s2d = new Label("- " + maxRevenue.getName() + " (" + maxRevenue.getPharmacyRevenue() + " EGP)");

        s1.setStyle("-fx-font-weight: bold;");
        s2.setStyle("-fx-font-weight: bold;");

        reportBox.getChildren().addAll(s1, s1d, s2, s2d);
    });


    productBtn.setOnAction(e -> {
        reportBox.getChildren().clear();

        List<Order> orders = getOrdersByDateRange(fromDate.getValue(), toDate.getValue());

        Map<Product, Integer> sold = new HashMap<>();
        Map<Product, Double> revenue = new HashMap<>();

        for (Order o : orders) {
            for (Map.Entry<Product, Integer> entry : o.getItems().entrySet()) {
                Product p = entry.getKey();
                int qty = entry.getValue();

                sold.put(p, sold.getOrDefault(p, 0) + qty);
                revenue.put(p, revenue.getOrDefault(p, 0.0) + p.getPrice() * qty);
            }
        }

        if (sold.isEmpty()) {
            reportBox.getChildren().add(new Label("No product data in this period."));
            return;
        }

        Product maxSold = Collections.max(sold.entrySet(), Map.Entry.comparingByValue()).getKey();
        Product maxRevenue = Collections.max(revenue.entrySet(), Map.Entry.comparingByValue()).getKey();

        reportBox.getChildren().addAll(
                new Label("Best Selling Product:"),
                new Label(maxSold.getName() + " (" + sold.get(maxSold) + " units)"),
                new Label("Highest Revenue Product:"),
                new Label(maxRevenue.getName() + " (" + revenue.get(maxRevenue) + " EGP)")
        );
    });

    customerBtn.setOnAction(e -> {
        reportBox.getChildren().clear();

        List<Order> orders = getOrdersByDateRange(fromDate.getValue(), toDate.getValue());

        Map<Customer, Integer> count = new HashMap<>();
        Map<Customer, Double> revenue = new HashMap<>();

        for (Order o : orders) {
            Customer c = o.getCustomer();
            count.put(c, count.getOrDefault(c, 0) + 1);
            revenue.put(c, revenue.getOrDefault(c, 0.0) + o.getTotalAmount());
        }

        if (count.isEmpty()) {
            reportBox.getChildren().add(new Label("No customer data in this period."));
            return;
        }

        Customer maxOrders = Collections.max(count.entrySet(), Map.Entry.comparingByValue()).getKey();
        Customer maxRevenue = Collections.max(revenue.entrySet(), Map.Entry.comparingByValue()).getKey();

        reportBox.getChildren().addAll(
                new Label("Customer With Most Orders:"),
                new Label(maxOrders.getName()),
                new Label("Customer With Highest Revenue:"),
                new Label(maxRevenue.getName())
        );
    });

    cashierBtn.setOnAction(e -> {
        reportBox.getChildren().clear();

        List<Order> orders = getOrdersByDateRange(fromDate.getValue(), toDate.getValue());

        Map<Cashier, Integer> count = new HashMap<>();
        Map<Cashier, Double> revenue = new HashMap<>();

        for (Order o : orders) {
            Cashier c = o.getCashier();
            count.put(c, count.getOrDefault(c, 0) + 1);
            revenue.put(c, revenue.getOrDefault(c, 0.0) + o.getTotalAmount());
        }

        if (count.isEmpty()) {
            reportBox.getChildren().add(new Label("No cashier data in this period."));
            return;
        }

        Cashier maxOrders = Collections.max(count.entrySet(), Map.Entry.comparingByValue()).getKey();
        Cashier maxRevenue = Collections.max(revenue.entrySet(), Map.Entry.comparingByValue()).getKey();

        reportBox.getChildren().addAll(
                new Label("Cashier With Most Orders:"),
                new Label(maxOrders.getName()),
                new Label("Cashier With Highest Revenue:"),
                new Label(maxRevenue.getName())
        );
    });

    layout.getChildren().addAll(title, dateBox, buttons, reportBox);
    return layout;
}


    public VBox showSuppliersPage() {
        ObservableList<Supplier> supplierList = FXCollections.observableArrayList(allSuppliers);
        TextField searchField = new TextField();
        searchField.setPromptText("Search Suppliers...");

        TableView<Supplier> table = new TableView<>();
        TableColumn<Supplier, Integer> idCol = new TableColumn<>("ID");
        TableColumn<Supplier, String> nameCol = new TableColumn<>("Name");
        TableColumn<Supplier, Integer> ordersCol = new TableColumn<>("Orders");
        TableColumn<Supplier, Double> revenueCol = new TableColumn<>("Revenue");

        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        ordersCol.setCellValueFactory(new PropertyValueFactory<>("pharmacyOrderCount"));
        revenueCol.setCellValueFactory(new PropertyValueFactory<>("pharmacyRevenue"));

        table.getColumns().addAll(idCol, nameCol, ordersCol, revenueCol);
        table.setItems(supplierList);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        
        Button addBtn = new Button("Add Supplier");
        addBtn.setOnAction(e -> showAddSupplierWindow());

        Button removeBtn = new Button("Remove Supplier");
        removeBtn.setOnAction(e -> showRemoveSupplierWindow());

        Button orderBtn = new Button("Place Pharmacy Order");
        orderBtn.setOnAction(e -> showPlaceOrderWindow());
        
        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal == null || newVal.isEmpty()) {
                table.setItems(supplierList);
            } else {
                String lower = newVal.toLowerCase();
                ObservableList<Supplier> filteredList = FXCollections.observableArrayList();

                for (Supplier supplier : supplierList) {
                    if (supplier.getName().toLowerCase().contains(lower)) {
                        filteredList.add(supplier);
                    }
                }
                table.setItems(filteredList);
            }
        });

        VBox layout = new VBox(10,searchField, table, new HBox(10, addBtn, removeBtn, orderBtn));
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);

        return layout;
    }

    public void showAddSupplierWindow() {
        Stage popup = new Stage();
        popup.setTitle("Add Supplier");

        TextField nameField = new TextField();
        nameField.setPromptText("Supplier name");

        Button save = new Button("Save");
        save.setOnAction(e -> {
            String name = nameField.getText().trim();
            if (name.isEmpty()) {
                showPopupMessage("Supplier name required.");
                return;
            }
            Supplier s = new Supplier(name);
            allSuppliers.add(s);
            PharmacyProject.saveAll();
            showPopupMessage("Supplier added.");
            popup.close();
        });

        VBox layout = new VBox(10, new Label("Supplier Name:"), nameField, save);
        layout.setPadding(new Insets(10));
        layout.setAlignment(Pos.CENTER);

        popup.setScene(new Scene(layout, 300, 150));
        popup.showAndWait();
    }

    public void showRemoveSupplierWindow() {
        Stage popup = new Stage();
        popup.setTitle("Remove Supplier");

        ComboBox<Supplier> supplierBox = new ComboBox<>();
        supplierBox.getItems().addAll(allSuppliers);

        Button remove = new Button("Remove");
        Label msg = new Label();

        remove.setOnAction(e -> {
            Supplier s = supplierBox.getValue();
            if (s == null) {
                msg.setText("Select a supplier to remove.");
                return;
            }
            // Optionally ensure no products depend on supplier name
            allSuppliers.remove(s);
            PharmacyProject.saveAll();
            msg.setText("Supplier removed.");
            popup.close();
        });

        VBox layout = new VBox(10, new Label("Select Supplier:"), supplierBox, remove, msg);
        layout.setPadding(new Insets(10));
        layout.setAlignment(Pos.CENTER);

        popup.setScene(new Scene(layout, 320, 180));
        popup.showAndWait();
    }

   public void showPlaceOrderWindow() {

    Stage popup = new Stage();
    popup.setTitle("Place Pharmacy Order");

    ComboBox<Supplier> supplierBox = new ComboBox<>();
    supplierBox.getItems().addAll(allSuppliers);

    ComboBox<Product> productBox = new ComboBox<>();
    productBox.setDisable(true);

    TextField qtyField = new TextField();
    qtyField.setPromptText("Quantity");

    TextField costField = new TextField();
    costField.setPromptText("Total cost");
    costField.setEditable(false);

    Label msg = new Label();

    supplierBox.setOnAction(e -> {
        Supplier selectedSupplier = supplierBox.getValue();
        productBox.getItems().clear();

        if (selectedSupplier != null) {
            for (Product p : allProducts) {
                if (p.getSupplier() != null && p.getSupplier().equals(selectedSupplier)) {
                    productBox.getItems().add(p);
                }
            }
            productBox.setDisable(false);
        }
    });

    ChangeListener<Object> costUpdater = (obs, oldVal, newVal) -> {
        Product p = productBox.getValue();
        if (p == null) {
            costField.clear();
            return;
        }

        try {
            int qty = Integer.parseInt(qtyField.getText().trim());
            if (qty > 0) {
                double total = qty * p.getPrice();
                costField.setText(String.format("%.2f", total));
            } else {
                costField.clear();
            }
        } catch (NumberFormatException ex) {
            costField.clear();
        }
    };

    qtyField.textProperty().addListener(costUpdater);
    productBox.valueProperty().addListener(costUpdater);

    Button place = new Button("Place Order");
    place.setOnAction(e -> {

        Supplier s = supplierBox.getValue();
        Product p = productBox.getValue();

        if (s == null || p == null) {
            msg.setText("Please select supplier and product.");
            return;
        }

        int qty;
        try {
            qty = Integer.parseInt(qtyField.getText().trim());
            if (qty <= 0) {
                msg.setText("Quantity must be greater than 0.");
                return;
            }
        } catch (NumberFormatException ex) {
            msg.setText("Invalid quantity.");
            return;
        }

        double totalCost = qty * p.getPrice();

        p.setQuantityInStock(p.getQuantityInStock() + qty);

        s.recordPharmacyOrder(totalCost);

        PharmacyProject.saveAll();

        showPopupMessage(
                "Pharmacy order placed:\n" +
                qty + " x " + p.getName() +
                "\nTotal cost: " + totalCost + " EGP"
        );

        popup.close();
    });

    VBox layout = new VBox(10,
            new Label("Supplier"), supplierBox,
            new Label("Product"), productBox,
            new Label("Quantity"), qtyField,
            new Label("Total Cost"), costField,
            place, msg
    );

    layout.setPadding(new Insets(12));
    layout.setAlignment(Pos.CENTER);

    popup.setScene(new Scene(layout, 360, 400));
    popup.showAndWait();
}


    public VBox showOrderssPage() {
        ObservableList<Order> observableOrderList = FXCollections.observableArrayList(PharmacyProject.allOrders);

        TableView<Order> table = new TableView<>();

        TableColumn<Order, Integer> idCol = new TableColumn<>("Order ID");
        TableColumn<Order, String> customerCol = new TableColumn<>("Customer");
        TableColumn<Order, String> cashierCol = new TableColumn<>("Cashier");
        TableColumn<Order, String> itemsCol = new TableColumn<>("Items");
        TableColumn<Order, String> dateCol = new TableColumn<>("Date");
        TableColumn<Order, Double> totalCol = new TableColumn<>("Total");
        TableColumn<Order, Integer> ratingCol = new TableColumn<>("Rating");
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        customerCol.setCellValueFactory(cellData -> new ReadOnlyStringWrapper(
                cellData.getValue().getCustomer().getName()));
        cashierCol.setCellValueFactory(cellData -> new ReadOnlyStringWrapper(
                cellData.getValue().getCashier().getName()));
        itemsCol.setCellValueFactory(cellData -> new ReadOnlyStringWrapper(
                cellData.getValue().getItems().entrySet().stream()
                        .map(e -> e.getKey().getName() + " x" + e.getValue())
                        .collect(Collectors.joining(", "))));
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        dateCol.setCellValueFactory(cellData -> new ReadOnlyStringWrapper(
                sdf.format(cellData.getValue().getDate())));
        totalCol.setCellValueFactory(new PropertyValueFactory<>("totalAmount"));
        ratingCol.setCellValueFactory(new PropertyValueFactory<>("rating"));

        table.getColumns().addAll(idCol, customerCol, cashierCol, itemsCol, dateCol, totalCol, ratingCol);
        table.setItems(observableOrderList);

        TextField searchField = new TextField();
        searchField.setPromptText("Search by name or product...");

        DatePicker dateFilter = new DatePicker();
        dateFilter.setPromptText("Filter by Date");

        searchField.textProperty().addListener((obs, oldVal, newVal) -> applyFilters(observableOrderList, table, searchField.getText(), dateFilter.getValue()));
        dateFilter.valueProperty().addListener((obs, oldVal, newVal) -> applyFilters(observableOrderList, table, searchField.getText(), newVal));

        VBox layout = new VBox(10, new Label("Search & Filter Orders"), searchField, dateFilter, table);
        layout.setPadding(new Insets(20));
        return layout;
    }

    private void applyFilters(ObservableList<Order> baseList, TableView<Order> table, String searchText, LocalDate selectedDate) {
        String lower = (searchText == null) ? "" : searchText.toLowerCase();

        ObservableList<Order> filtered = FXCollections.observableArrayList();

        for (Order order : baseList) {
            boolean matchesSearch = lower.isEmpty()
                    || order.getCustomer().getName().toLowerCase().contains(lower)
                    || order.getCashier().getName().toLowerCase().contains(lower)
                    || order.getItems().keySet().stream().anyMatch(p -> p.getName().toLowerCase().contains(lower));

            boolean matchesDate = true;
            if (selectedDate != null) {
                Date orderDate = order.getDate();
                LocalDate orderLocalDate = orderDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                matchesDate = selectedDate.equals(orderLocalDate);
            }

            if (matchesSearch && matchesDate) {
                filtered.add(order);
            }
        }

        table.setItems(filtered);
    }

    @Override
    public Scene homePage() {
        BorderPane root = new BorderPane();

        Label title = new Label("Admin Menu");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        Button usersBtn = new Button("Users");
        usersBtn.setOnAction(e -> root.setCenter(showUsersPage()));

        Button productsBtn = new Button("Products");
        productsBtn.setOnAction(e -> root.setCenter(showProductsPage()));

        Button ordersBtn = new Button("Orders");
        ordersBtn.setOnAction(e -> root.setCenter(showOrderssPage()));

        Button suppliersBtn = new Button("Suppliers");
        suppliersBtn.setOnAction(e -> root.setCenter(showSuppliersPage()));

        Button reportsBtn = new Button("Reports");
        reportsBtn.setOnAction(e -> root.setCenter(showReportsPage()));

        Button logoutBtn = new Button("Logout");
        logoutBtn.setOnAction(e -> stage.setScene(LoginScreen()));

        VBox Box = new VBox(12, title, usersBtn, productsBtn, ordersBtn, suppliersBtn, reportsBtn, logoutBtn);
        Box.setPadding(new Insets(20));
        Box.setAlignment(Pos.CENTER);

        root.setLeft(Box);
        root.getStylesheets().add(
            PharmacyProject.class.getResource("style.css").toExternalForm()
        );

        return new Scene(root, 900, 580);
    }
}